#!/usr/bin/env python
# coding: utf-8

# # Predicting Head Injury Severity in a Car Crash using Multiple Regression

# ### Describe data
# 
# * MAKE - It tells the company of the car.
# * MODEL - It tells the model of the car.
# * CARID - It is the unique name by which we can know the company and the model of the company. It uniquely identifies a certain type of car from another.
# * CARID_YR - It also contains the CARID, but along with it also tells the year in which it was released.
# * HEAD_INJ - Number of head injuries in an accident in a certain type of car.
# * CHEST_IN - Number of chest injuries in an accident in a certain type of car.
# * LLEG_INJ - Number of injuries in left leg in an accident in a certain type of car.
# * RLEG_INJ - Number of injuries in right leg in an accident in a certain type of car.
# * DRIV_PAS - Whether the passenger got hurt or the driver.
# * PROTECT - What type of protection was available in the vehicle.
# * DOORS - Number of doors in the vehicle.
# * YEAR - In what year the car was launched.
# * WEIGHT -  Tells the weight of the car.
# * SIZE -  Categorize the cars by their size.
# * SIZE2 -  Size in numeric value for the category of size to which the car belongs.
# * PROTECT2 - Numeric value for the protection in the car.
# 

# ### Explore data

# In[ ]:


# get the libraries for analysis and model building
import pandas as pd
import numpy as np
import statsmodels.api as sm;
import seaborn as sns
import matplotlib.pyplot as plt

get_ipython().run_line_magic('matplotlib', 'inline')

# load the dataset as DataFrame
df = pd.read_csv('Crash.dat',sep='\t') 

# View the first 5 rows of the dataset
df.head()


# In[ ]:


# dataset size , i.e., number of rows x columns
df.shape


# In[ ]:


# display the name of the columns in the dataset
df.columns


# In[ ]:


# Total number of unique values under each column
df.nunique()


# In[ ]:


# short summary of the dataset, i.e.,
# col_name    data_count    value_type    data_type
df.info()


# In[ ]:


df.describe()


# 
# ### Verify data quality
# 

# In[ ]:


# Total count of duplicate rows in the dataset
df.duplicated().sum()


# In[ ]:


# Count of null values in the dataset
df.isnull().sum()


# In[ ]:


df.dtypes


# # Data prepration

# ### Data Cleaning report
# 
# no. of incorrect values, no. of missing fields, no. of blank fields (data cleaning reports)
# 

# In[ ]:


# Fill in empty spaces with NaN values by extracting values from strings
# Columns = HEAD_INJ, CHEST_INJ,LLEG_INJ, RLEG_INJ, DOORS, PROTECT2
df['HEAD_INJ'] = df['HEAD_INJ'].str.extract('(\d+)')
df['CHEST_IN'] = df['CHEST_IN'].str.extract('(\d+)')
df['LLEG_INJ'] = df['LLEG_INJ'].str.extract('(\d+)')
df['RLEG_INJ'] = df['RLEG_INJ'].str.extract('(\d+)')
df['DOORS']    = df['DOORS'].str.extract('(\d+)')
df['PROTECT2'] = df['PROTECT2'].str.extract('(\d+)')

df.head()


# In[ ]:


# Count of null values in the dataset (After conversion from empty string to NaN)
df.isnull().sum()


# In[ ]:


# Dropping all rows with null values in HEAD_INJ column
df.dropna(subset=['HEAD_INJ'],inplace=True)


# In[ ]:


# Convert object(string) type columns into integer type
df['HEAD_INJ'] = df['HEAD_INJ'].astype('int64')


# In[ ]:


# fill NaN in other columns with average value of respective columns
# 'CHEST_IN','LLEG_INJ','RLEG_INJ','DOORS','PROTECT2'

val = df['CHEST_IN'].dropna() # drop NaN value in the column
val = pd.to_numeric(val)       # convert the col values to numeric
mean_val = round(val.mean())       # get rounded mean of the column
df['CHEST_IN'].fillna(mean_val,inplace=True) # fillin the Mean Value in NaN of actual column

# applying smae steps for other columns

val = df['LLEG_INJ'].dropna() 
val = pd.to_numeric(val)      
mean_val = round(val.mean())  
df['LLEG_INJ'].fillna(mean_val,inplace=True)

val = df['RLEG_INJ'].dropna() 
val = pd.to_numeric(val)    
mean_val = round(val.mean())       
df['RLEG_INJ'].fillna(mean_val,inplace=True) 

val = df['DOORS'].dropna() 
val = pd.to_numeric(val)       
mean_val = round(val.mean())   
df['DOORS'].fillna(mean_val,inplace=True) 

val = df['PROTECT2'].dropna() 
val = pd.to_numeric(val)      
mean_val = round(val.mean())  
df['PROTECT2'].fillna(mean_val,inplace=True) 

df[['CHEST_IN','LLEG_INJ','RLEG_INJ','DOORS','PROTECT2']].isnull().sum()


# In[ ]:


# Convert object(string) type columns into integer type
df[['HEAD_INJ','CHEST_IN','LLEG_INJ','RLEG_INJ','DOORS','PROTECT2']] = df[['HEAD_INJ','CHEST_IN','LLEG_INJ',
                                                                           'RLEG_INJ','DOORS','PROTECT2']].astype('int64')
df.dtypes


# In[ ]:


df.describe()


# 
# ### Format  and cimbine data
# 
# integrate the data
# 

# In[ ]:


df['intercept'] = 1
lm = sm.OLS(df['HEAD_INJ'],df[['intercept','CHEST_IN','LLEG_INJ','RLEG_INJ','DOORS','YEAR','WEIGHT','SIZE2','PROTECT2']])
results = lm.fit()
results.summary()


# In[ ]:


sns.pairplot(df[['HEAD_INJ','CHEST_IN','LLEG_INJ','RLEG_INJ','DOORS','PROTECT2']]);


# In[ ]:


from patsy import dmatrices
from statsmodels.stats.outliers_influence import variance_inflation_factor


# In[ ]:


y,X = dmatrices('HEAD_INJ~intercept+CHEST_IN+LLEG_INJ+RLEG_INJ+DOORS+YEAR+WEIGHT+SIZE2+PROTECT2',df,return_type='dataframe')


# In[ ]:


vif = pd.DataFrame()
vif['vifFactor'] = [variance_inflation_factor(X.values,i) for i in range(X.shape[1])]
vif['features'] = X.columns


# In[ ]:


vif


# In[ ]:


pd.plotting.scatter_matrix(df,figsize=(20,20));


# In[ ]:


df.plot(kind='scatter',x='HEAD_INJ',y='YEAR',figsize=(15,15),grid=True)


# In[ ]:


# Which company make had highest head injury count
a = df.groupby(['MAKE'],as_index=False).sum()
m = (a["HEAD_INJ"].max())
a[a['HEAD_INJ']>=m]


# In[ ]:


# Which company make had lowest head injury count
a = df.groupby(['MAKE'],as_index=False).sum()
m = (a["HEAD_INJ"].min())
a[a['HEAD_INJ']<=m]


# In[ ]:


# Which year car make had the highest head injury
a = df.groupby(['YEAR'],as_index=False).sum()
m = (a["HEAD_INJ"].max())
a[a['HEAD_INJ']>=m]


# In[ ]:


# WHch year car make had the lowest head injury
a = df.groupby(['YEAR'],as_index=False).sum()
m = (a["HEAD_INJ"].min())
a[a['HEAD_INJ']<=m]


# In[ ]:


# whihc TYpes of protection have highest influence on head injury
a = df.groupby(['PROTECT2'],as_index=False).sum()
m = (a["HEAD_INJ"].max())
a[a['HEAD_INJ']>=m]


# In[ ]:


# whihc TYpes of protection have least influence on head injury
a = df.groupby(['PROTECT2'],as_index=False).sum()
m = (a["HEAD_INJ"].min())
a[a['HEAD_INJ']<=m]


# In[ ]:


# Significance of doors on  head injury
a = df.groupby(['DOORS'],as_index=False).sum()
m = (a["HEAD_INJ"].max())
a[a['HEAD_INJ']>=m]


# In[ ]:


plt.bar(a['DOORS'],a['HEAD_INJ']);


# In[ ]:


# Driver had more injury or passenger (line graph plot of driver and passenger based on various factors)
a = df.groupby(['DRIV_PAS'],as_index=False).mean()
m = (a["HEAD_INJ"].max())
a


# In[ ]:


df[['HEAD_INJ','CHEST_IN','LLEG_INJ','RLEG_INJ']].describe()


# * Max: 3665 (HEAD_INJ)
# * Min: 31 (CHEST_INJ)

# In[ ]:


plt.figure(figsize=(12,8))
sns.lineplot(df['YEAR'],df['HEAD_INJ'],df['DRIV_PAS'],palette="tab10", linewidth=2.5).set_title('Head Injury Over the Years');


# In[ ]:


plt.figure(figsize=(12,8))
sns.lineplot(df['YEAR'],df['CHEST_IN'],df['DRIV_PAS'],palette="tab10", linewidth=2.5).set_title('Chest Injury Over the Years');


# In[ ]:


plt.figure(figsize=(12,8))
sns.lineplot(df['YEAR'],df['LLEG_INJ'],df['DRIV_PAS'],palette="tab10", linewidth=2.5).set_title('Left Leg Injury Over the Years');


# In[ ]:


plt.figure(figsize=(12,8))
sns.lineplot(df['YEAR'],df['RLEG_INJ'],df['DRIV_PAS'],palette="tab10", linewidth=2.5).set_title('Right Leg Injury Over the Years');


# In[ ]:


# Over the years have the head injury safety improved ? And which injury has declined?
plt.figure(figsize=(12,8))
sns.lineplot(df[['HEAD_INJ','CHEST_IN','LLEG_INJ','RLEG_INJ']],df['YEAR'],columns=['HEAD_INJ','CHEST_IN','LLEG_INJ','RLEG_INJ'],palette="tab10", linewidth=2.5).set_title('Injuries Over the Years');


# In[ ]:


rs = np.random.RandomState(365)
values = rs.randn(365, 4).cumsum(axis=0)
dates = pd.date_range("1 1 2016", periods=365, freq="D")
data = pd.DataFrame(values, dates, columns=["A", "B", "C", "D"])
data = data.rolling(7).mean()
values

