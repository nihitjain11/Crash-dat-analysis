#Read the dataset
ds = read.csv("F:/crash-dat-analysis-master/crash-dat-analysis-master/Crash.csv",sep =
'\t')
View(ds)

#Data cleaning
ds$CHEST_IN[is.na(ds$CHEST_IN)]<-mean(ds$CHEST_IN,na.rm = TRUE)
ds$HEAD_INJ[is.na(ds$HEAD_IN)]<-mean(ds$HEAD_IN,na.rm = TRUE)
ds$LLEG_INJ[is.na(ds$LLEG_IN)]<-mean(ds$LLEG_IN,na.rm = TRUE)
ds$RLEG_INJ[is.na(ds$RLEG_IN)]<-mean(ds$RLEG_IN,na.rm = TRUE)
ds$DOORS = as.numeric(ds$DOORS)
ds$DOORS[is.na(ds$DOORS)]<-mean(ds$DOORS,na.rm = TRUE)
ds$WEIGHT[is.na(ds$WEIGHT)]<-mean(ds$WEIGHT,na.rm = TRUE)
ds$SIZE2[is.na(ds$SIZE2)]<-mean(ds$SIZE2,na.rm = TRUE)
ds$PROTECT2[is.na(ds$PROTECT2)]<-mean(ds$PROTECT2,na.rm = TRUE)

#ds$SIZE2 = as.numeric(ds$SIZE2)

#Indicator variables
lv  =  levels(ds$MAKE)
lb  =  length(levels(ds$MAKE))
ds$MAKE  =  as.numeric(factor(ds$MAKE,
 levels  =  lv,
 labels  =  c(1:lb)) )
ds$DRIV_PAS  =  factor(ds$DRIV_PAS,
 levels  =  c('Driver','Passen'),
 labels  =  c(1,2))

#Data spliting in training set and validation set
ind = sample(2,nrow(ds),replace = TRUE, prob = c(0.8,0.2))

#traing set made of 80% of the data
tdata = ds[ind == 1,]

#validation set made of 20% of the data
vdata = ds[ind == 2,]

#Multiple regression

#regression model using all the variables
result1 = lm(HEAD_INJ~CHEST_IN+MAKE+LLEG_INJ+RLEG_INJ+DRIV_PAS+
DOORS+YEAR+WEIGHT+SIZE2+PROTECT2,tdata)

#for all variables
y_pred = predict(result1,newdata = vdata)

#Using backward elimination to get the best regression model
step(result1, direction = "backward")

#based on backward elimination best model is:
result1 = lm(formula = HEAD_INJ ~ CHEST_IN + DOORS + WEIGHT +
PROTECT2,
 data = tdata)
y_pred = predict(result1,newdata = vdata)
View(y_pred)

#creating a new column which is based on all the four type of injury
ds$TOTAL_INJ = ds$HEAD_INJ+ds$CHEST_IN+ds$LLEG_INJ+ds$RLEG_INJ

#Data spliting in training set and validation set
ind = sample(2,nrow(ds),replace = TRUE,prob = c(0.8,0.2))

#traing set made of 80% of the data
tdata = ds[ind == 1,]

#validation set made of 20% of the data
vdata = ds[ind == 2,]

#Multiple regression

#regression model using all the variables
result1 = lm(TOTAL_INJ~MAKE+DRIV_PAS+DOORS+YEAR+WEIGHT+SIZE2+
PROTECT2,tdata)

#for all variables
y_pred = predict(result1,newdata = vdata)

#Using backward elimination to get the best regression model
step(result1, direction = "backward")

#based on backward elimination best model is:
result1 = lm(formula = TOTAL_INJ ~ MAKE + DRIV_PAS + WEIGHT, data = tdata)
y_pred = predict(result1,newdata = vdata)
View(y_pred)